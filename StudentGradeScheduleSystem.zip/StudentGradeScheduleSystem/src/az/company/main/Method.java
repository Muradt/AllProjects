package az.company.main;

public class Method {

}
