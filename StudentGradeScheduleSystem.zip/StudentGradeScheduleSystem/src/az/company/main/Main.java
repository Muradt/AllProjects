package az.company.main;

import java.util.List;
import java.util.Scanner;

import az.company.members.Dechan;
import az.company.members.Tyutor;

public class Main {

	public static void main(String[] args) throws Exception {
		System.out.println("Welcome to Our Console App !");
		System.out.println("Enter as a ...\n1.Dechan\n2.Tyutor\n3.Student");
		int choice;
		Scanner sc = new Scanner(System.in);
		System.out.print("Choice : ");
		choice = sc.nextInt();
		switch (choice) {
		case 1:
			System.out.println("Enter user name :");
			String userName = sc.nextLine();
			sc.nextLine();
			System.out.println("Enter password :");
			String password = sc.nextLine();
			System.out.println(userName+" "+password);
			if(Dechan.DECHAN_USER_NAME.trim().equals(userName) && Dechan.DECHAN_PASSWORD.trim().equals(password))
				Dechan.seeSchedule();
			else
				System.err.println("Wrong User Name or Password !");

			break;
		case 2:
			System.out.println("Enter user name :");
			String userName2 = sc.next();
			System.out.println("Enter password :");
			String password2 = sc.next();
			if(Tyutor.TYUTOR_USER_NAME.equals(userName2)&&Dechan.DECHAN_PASSWORD.equals(password2))
				Tyutor.setStudentInformation();
			else
				System.err.println("Wrong User Name or Password !");
			 

		case 3:
			break;
		default:
			System.err.println("Invalid Input");
		}
	}

}
